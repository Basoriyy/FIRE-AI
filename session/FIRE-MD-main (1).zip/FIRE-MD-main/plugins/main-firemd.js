let handler = async m =>
  m.reply(
    `

≡  *FIRE MD ┃

─────────────
▢ Join public bot group and support
https://chat.whatsapp.com/F3sB3pR3tClBvVm

▢ Group 2
https://chat.whatsapp.com/LwLQab5mZVW6

▢ Group 3
https://chat.whatsapp.com/Jn9qVe

─────────────
≡ Disabled links? enter here! 

▢ Group WhatsApp 
 https://chat.whatsapp.com/F3sB3
─────────────
▢ *Owner Telegram*
 https://t.me/i_w

▢ *YouTube*
• https://www.youtube.com/


`.trim()
  )
handler.help = ['gpguru']
handler.tags = ['main']
handler.command = ['groups', 'groupfire', 'gugp', 'ggp', 'gpfire*']

export default handler
